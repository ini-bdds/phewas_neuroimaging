function NeuroimagingPheWAS
% NeuroimagingPheWAS, a toolbox for whole-brain PheWAS analysis, multiple
% comparisons correction and result visualization. 
%-----------------------------------------------------------
%	Copyright(c) 2016
%	University of Southern California
%	Written by Lu Zhao
%	Mail to Author:  <a href="lu.zhao@loni.usc.edu">Lu Zhao</a>
%   Version 1.0;
%   Date 08.15.2016;
%   Last edited 08.15.2016
%-----------------------------------------------------------
%
% NeuroimagingPheWAS.m creates the welcome interface for NeuroimagingPheWAS.




clc;fprintf('Welcome to NeuroimagingPheWAS \n');


global hnd_main  

RectW = NeuroimagingPheWAS_GUI_scale('WinSize','W',1); % 400x250 figure
Rect0 = NeuroimagingPheWAS_GUI_scale('WinSize','0',1);
Pos   = [Rect0(1)+(Rect0(3)-RectW(3))/2,...
        Rect0(2)+(Rect0(4)-RectW(4))/2,...
        RectW(3),...
        RectW(4)];
    
if ~usejava('awt')
     h=msgbox('Java is not installed!', 'Error','error');
     set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 200 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
     uiwait(h);       
     return;
end
    
    
hnd_main.mainfig=figure('Name','NeuroimagingPheWAS v1.0','Numbertitle','off','Toolbar','none','Menubar','none'); 
  set(hnd_main.mainfig,'units','pixels','position',Pos,'Color','w');

%% text and buttons

hnd_main.title=uicontrol(hnd_main.mainfig,'units','pixels','style','text',...
      'position',[50 140 400 50],'string','Neuroimaging PheWAS','FontSize',32,...
      'FontAngle','Italic','backgroundcolor',[1 1 1],'HorizontalAlignment','center');

hnd_main.BDDSlogo_part1=uicontrol(hnd_main.mainfig,'units','pixels','style','text',...
      'position',[15 25 50 30],'string','BD','FontSize',32,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.7 0 0],'HorizontalAlignment','left');   
hnd_main.BDDSlogo_part2=uicontrol(hnd_main.mainfig,'units','pixels','style','text',...
      'position',[59 25 50 30],'string','DS','FontSize',32,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0 0 0.4],'HorizontalAlignment','left');
hnd_main.BDDSlogo_part3=uicontrol(hnd_main.mainfig,'units','pixels','style','text',...
      'position',[110 20 70 25],'string','Big Data','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.7 0 0],'HorizontalAlignment','left');
hnd_main.BDDSlogo_part4=uicontrol(hnd_main.mainfig,'units','pixels','style','text',...
      'position',[185 20 30 25],'string','for','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.5 0.5 0.5],'HorizontalAlignment','left');
hnd_main.BDDSlogo_part5=uicontrol(hnd_main.mainfig,'units','pixels','style','text',...
      'position',[212 20 160 25],'string','Discovery Science','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0 0 0.4],'HorizontalAlignment','left');  

hnd_main.startPWS=uicontrol(hnd_main.mainfig,'units','pixels','style','pushbutton',...
      'position',[25 90 460 35],'string','PheWAS on Surface-Based Neuroimaging Phenotypes','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.5 0 0],'callback',@startPWS);

hnd_main.quit=uicontrol(hnd_main.mainfig,'units','pixels','style','pushbutton',...
   'position',[460 10 40 25],'string','Quit','FontSize',16, ...
   'backgroundcolor',[1 1 1],'callback',@quit);
%% callback functions 
function startPWS(varargin)  
 close(gcf)  
 clear global hnd_main data  
 NeuroimagingPheWAS_SBM_GUI
end 

function quit(varargin)  
 close(gcf)  
 clear global hnd_main data  
 fprintf('Thanks for using NeuroimagingPheWAS. Bye! \n');
end

end