function NeuroimagingPheWAS_SBM_GUI
% NeuroimagingPheWAS, a toolbox for whole-brain PheWAS analysis, multiple
% comparisons correction and result visualization. 
%-----------------------------------------------------------
%	Copyright(c) 2016
%	University of Southern California
%	Written by Lu Zhao
%	Mail to Author:  <a href="lu.zhao@loni.usc.edu">Lu Zhao</a>
%   Version 1.0;
%   Date 08.15.2016;
%   Last edited 08.15.2016
%-----------------------------------------------------------
%
% NeuroimagingPheWAS_SBM_GUI.m creates the user interface for conducting PheWAS
% on surface-based brain morphological phenotypes. Please read the manual
% for detailed use of the GUI.

%% main figure
global hnd_SBMPWS 
RectW = NeuroimagingPheWAS_GUI_scale('WinSize','S',1); 
Rect0 = NeuroimagingPheWAS_GUI_scale('WinSize','0',1);
Pos   = [Rect0(1)+(Rect0(3)-RectW(3))/2,...
         Rect0(2)+(Rect0(4)-RectW(4))/2,...
         RectW(3),...
         RectW(4)];
hnd_SBMPWS.mainfig=figure('Name','PheWAS on Surface-Based Neuroimaging Phenotypes','Numbertitle','off','Toolbar','none','Menubar','none'); 
   set(hnd_SBMPWS.mainfig,'units','pixels','position',Pos,'Color','w');

hnd_SBMPWS.title=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[340 720 600 30],'string','PheWAS on Surface-Based Neuroimaging Phenotypes','ForegroundColor','b','FontSize',20,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center');     
%% flags for data sets required for neuroimaging PheWAS
global databagstatus databagfields
databagstatus=zeros(1,4); 
databagfields=cell(1,4);
databagfields(1)={'Surface Model'};
databagfields(2)={'Genotype Data'};
databagfields(3)={'Model'};
databagfields(4)={'Phenotype Data'};
%% surface panel   
hnd_SBMPWS.panel_surfacemodel=uipanel('Parent',hnd_SBMPWS.mainfig,'Title','Surface Model',...
        'Units','pixels','Position',[20 570 640 150],'BackgroundColor','w','BorderType','etchedin');
hnd_SBMPWS.panel_surfviewer=uipanel('Parent',hnd_SBMPWS.mainfig,'Title','Surface Viewer',...
        'Units','pixels','Position',[20 30 640 540],'BackgroundColor','w','BorderType','etchedin'); 
hnd_SBMPWS.surfacemodel=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[30 665 70 30],'UserData',[],'string','Surface','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@surfacemodel);

hnd_SBMPWS.surf_dir=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[110 665 450 30],'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','left');

hnd_SBMPWS.load_surface=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[570 665 70 30],'UserData',struct('surf_model',[],'a',[],'cb',[],'inflation',0,'mask',1),...
       'string','Load','FontSize',12,'backgroundcolor',[1 1 1],'callback',@load_surface);
   
hnd_SBMPWS.txt_inflation=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[30 620 70 30],'string','Inflation','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center');
   
hnd_SBMPWS.inflateckeck=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','checkbox',...
       'position',[110 632 20 20],'backgroundcolor',[1 1 1],...
       'UserData',[],'callback',@inflatecheck);

hnd_SBMPWS.inflateR=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
    'position',[150 627 70 30],'string','0.3','FontSize',12,...
    'backgroundcolor',[1 1 1],'HorizontalAlignment','left','visible','off');
hnd_SBMPWS.inflatetrigger=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
    'position',[240 627 70 30],'UserData',[],'string','Apply','FontSize',12,...
    'backgroundcolor',[1 1 1],'visible','off','callback',@apply_inflation);

hnd_SBMPWS.surfacemask=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[30 590 70 30],'UserData',[],'string','Mask','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@surfacemask);

hnd_SBMPWS.mask_dir=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[110 590 450 30],'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','left');

hnd_SBMPWS.apply_mask=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[570 590 70 30],'UserData',[],'string','Apply','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@apply_mask);

hnd_SBMPWS.clear_surfviewer=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[580 40 70 40],'UserData',[],'string','<html>Clear<br>Viewer</html>','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@clear_surfviewer);   
 
hnd_SBMPWS.save_image=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[30 40 70 40],'UserData',[],'string','<html>Save<br>Image</html>','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@save_image);      
   
%% geno data control panel   
hnd_SBMPWS.panel_genodatacontrol=uipanel('Parent',hnd_SBMPWS.mainfig,'Title','Genotype Data Control',...
        'Units','pixels','Position',[680 640 580 80],'BackgroundColor','w','BorderType','etchedin');          
   
hnd_SBMPWS.genodata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[690 675 150 30],'string','Genotype Data','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'callback',@genodata);  
   
hnd_SBMPWS.genodatapath=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[850 675 320 30],'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','left');  

hnd_SBMPWS.loadgenodata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1180 675 70 30],'string','Load','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'callback',@loadgenodata);     

hnd_SBMPWS.txt_genodata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[690 645 300 20],'string','Genotype data has NOT been loaded :(','ForegroundColor','r','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','left');
   
hnd_SBMPWS.txt_snpID=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
   'position',[950 645 100 20],'string','','FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','left','visible','off');  
hnd_SBMPWS.snpdistribution=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
   'position',[1150 645 100 20],'string','SNP Distribution','FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[], 'visible','off','callback',@snpdistribution);    
   
%% Model control panel   
hnd_SBMPWS.panel_modelcontrol=uipanel('Parent',hnd_SBMPWS.mainfig,'Title','Model Control',...
        'Units','pixels','Position',[680 490 580 140],'BackgroundColor','w','BorderType','etchedin');          
   
hnd_SBMPWS.txt_model=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[690 590 50 20],'string','Model:','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center');  
hnd_SBMPWS.model=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[740 590 510 25],'backgroundcolor',[1 1 1].*0.8,...
       'string','1 + genotype','FontSize',12,'HorizontalAlignment','left');     
set(hnd_SBMPWS.model,'KeyPressFcn',@modelbgcolor); % create a function to change the background color when editing the model

hnd_SBMPWS.covdata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[690 555 150 30],'string','Covariates Data','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'callback',@covdata);  
   
hnd_SBMPWS.covdatapath=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[850 555 320 30],'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','left');  

hnd_SBMPWS.loadcovdata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1180 555 70 30],'string','Load','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'callback',@loadcovdata);     

hnd_SBMPWS.txt_covdata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[690 495 300 20],'string','Covariates data has NOT been loaded :(','ForegroundColor','r','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','left');  

hnd_SBMPWS.txt_modelstatus=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[1000 495 150 20],'string','Model is NOT choosen :(','ForegroundColor','r','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','left');   
   
hnd_SBMPWS.choosemodel=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1155 495 95 25],'string','Choose Model','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'callback',@choosemodel);     
   
hnd_SBMPWS.txt_cov=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
   'position',[690 523 70 20],'string','Covariates:','FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','visible','off');
hnd_SBMPWS.covlist=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
   'position',[760 525 100 20],'string','','FontSize',12,'visible','off');
hnd_SBMPWS.covorder=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
   'position',[860 525 100 20],'string','linear|quadratic|cubic','FontSize',12,'visible','off');

hnd_SBMPWS.txt_interaction=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
   'position',[960 523 70 20],'string','Interaction','FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','visible','off');
hnd_SBMPWS.interactionckeck=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','checkbox',...
   'position',[1030 525 20 20],'backgroundcolor',[1 1 1],...
   'UserData',[],'visible','off','callback',@interactionckeck);
hnd_SBMPWS.addcov=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
   'position',[900 495 80 25],'string','Add to Model','FontSize',12,...
   'backgroundcolor',[1 1 1],'UserData',[],'visible','off','callback',@addcov);
hnd_SBMPWS.covlist2=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
        'position',[1055 525 100 20],'string','','FontSize',12,'visible','off');
hnd_SBMPWS.covorder2=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
        'position',[1155 525 100 20],'string','linear|quadratic|cubic','FontSize',12,'visible','off');

   
%% pheno data control panel   

hnd_SBMPWS.panel_phenodatacontrol=uipanel('Parent',hnd_SBMPWS.mainfig,'Title','Phenotype Data Control',...
        'Units','pixels','Position',[680 320 580 160],'BackgroundColor','w','BorderType','etchedin'); 
   
hnd_SBMPWS.phenodataDIR=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[690 435 150 30],'string','Phenotype Data DIR','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@phenodataDIR);  

hnd_SBMPWS.phenodatadir=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[850 435 400 30],'UserData',[],'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','left');    
      
hnd_SBMPWS.phenoclasslist=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[690 395 150 30],'string','Phenotype Classes List','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@phenoclasslist);   
hnd_SBMPWS.phenoclasslistdir=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
       'position',[850 395 320 30],'UserData',[],'FontSize',12,...
       'backgroundcolor',[1 1 1]);    
hnd_SBMPWS.loadphenoclasslist=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1180 395 70 30],'string','load','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'callback',@loadphenoclasslist);     
   
hnd_SBMPWS.viewphenomean=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1110 325 140 30],'string','View Phenotype Mean','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off','callback',@viewphenomean);    
hnd_SBMPWS.txt_phenodata=uicontrol(hnd_SBMPWS.mainfig,'units','pixel','style','text',...
       'position',[690 325 300 20],'string','Phenotype data has NOT been loaded :(','ForegroundColor','r','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','left');   
str=sprintf('Phenotype\nClasses'); 
hnd_SBMPWS.txt_phenoclass=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
   'position',[690 360 70 30],'string',str,'FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','visible','off');  
hnd_SBMPWS.phenotypeclass=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
   'position',[760 355 120 30],'string','','UserData',[],'FontSize',12,'visible','off','callback',@checkselectedphenotypedata);
str=sprintf('Smoothing\nKernel'); 
hnd_SBMPWS.txt_kernel=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
   'position',[890 360 70 30],'string',str,'FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','visible','off');  
hnd_SBMPWS.kernel=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit',...
   'position',[965 360 40 30],'string','20','UserData',[],'FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','visible','off');
hnd_SBMPWS.txt_kernel_unit=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
   'position',[1005 355 30 30],'string','mm','UserData',[],'FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','visible','off');

hnd_SBMPWS.loadphenodata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
   'position',[1110 360 140 30],'string','Load Phenotype Data','FontSize',12,...
   'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off','callback',@loadphenodata);    

%% PheWAS control panel
hnd_SBMPWS.panel_phewascontrol=uipanel('Parent',hnd_SBMPWS.mainfig,'Title','PheWAS Control',...
        'Units','pixels','Position',[680 120 580 190],'BackgroundColor','w','BorderType','etchedin'); 
    
hnd_SBMPWS.validatedatabag=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[690 265 110 30],'string','Validate Databag','FontSize',12,...
       'backgroundcolor',[1 1 1],'callback',@validatedatabag);     
hnd_SBMPWS.txt_databagstatus=uicontrol(hnd_SBMPWS.mainfig,'units','pixel','style','text',...
       'position',[810 273 400 15],'string','','ForegroundColor','r','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','left','visible','off');    
hnd_SBMPWS.databagtidy=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1150 265 100 30],'string','Tidy Databag','FontSize',12,'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','center','UserData',[], 'visible','off','callback',@databagtidy);   
   
hnd_SBMPWS.txt_maineffect=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[690 235 70 15],'string','Main Effect:','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off');
hnd_SBMPWS.maineffect=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
       'position',[760 238 150 15],'string','test','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off','callback',@action_maineffect);  
hnd_SBMPWS.txt_test=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[930 235 30 15],'string','test:','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off');   
hnd_SBMPWS.testlist=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup','position',[960 238 150 15],...
       'string','ANOVA|t-test|Linear Regression|F-test','FontSize',12,'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','center','UserData',{'ANOVA','t-test','Linear Regression','F-test'},'visible','off','callback',@action_testlist);
hnd_SBMPWS.doanalysis=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1170 230 80 30],'string','Do Analysis','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off','callback',@doanalysis);    

hnd_SBMPWS.txt_effectsign=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[690 187 70 30],'string','Effect Sign:','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',[],'visible','off');   
hnd_SBMPWS.effectsign=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','popup',...
       'position',[760 205 60 15],'string','+|-','FontSize',12,...
       'backgroundcolor',[1 1 1],'HorizontalAlignment','center','UserData',{'+','-'},'visible','off');   
hnd_SBMPWS.uncorrectedpmap=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[840 195 120 30],'string','-log(uncorrected P)','FontSize',12,'backgroundcolor',[1 1 1],...
       'HorizontalAlignment','center','UserData',[],'visible','off','callback',@uncorrectedpmap);  
str=sprintf('uncorrected P\nThreshold');   
hnd_SBMPWS.txt_uncorrPthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'position',[970 195 100 30],'FontSize',12,'backgroundcolor',[1 1 1],'string',str,'visible','off');         
hnd_SBMPWS.uncorrPthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit','HorizontalAlignment','left',...
       'position',[1075 195 70 30],'FontSize',12,'backgroundcolor',[1 1 1],'string','0.05','visible','off');              
hnd_SBMPWS.applyucorrPthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[1170 195 80 30],'string','Threshold','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'visible','off','callback',@applyucorrPthrhd); 
   
hnd_SBMPWS.txt_clusthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'HorizontalAlignment','center','position',[690 168 120 15],'FontSize',12,...
       'backgroundcolor',[1 1 1],'string','Cluster Threshold','visible','off'); 
hnd_SBMPWS.clusthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit','HorizontalAlignment','left',...
       'position',[840 160 70 30],'FontSize',12,'backgroundcolor',[1 1 1],'string','0.001','visible','off');  
hnd_SBMPWS.surfstatRFT=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[950 160 70 30],'string','RFT','FontSize',12,...
       'backgroundcolor',[1 1 1],'UserData',[],'visible','off','callback',@surfstatRFT);  
hnd_SBMPWS.txt_FDRthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
       'HorizontalAlignment','center','position',[690 135 120 15],'FontSize',12,...
       'backgroundcolor',[1 1 1],'string','FDR Threshold','visible','off');   
hnd_SBMPWS.FDRthrhd=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','edit','HorizontalAlignment','left',...
       'position',[840 125 70 30],'FontSize',12,'backgroundcolor',[1 1 1],'string','0.05','visible','off');  
hnd_SBMPWS.surfstatFDR=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
       'position',[950 125 70 30],'string','FDR','FontSize',12,...
       'backgroundcolor',[1 1 1],'backgroundcolor',[1 1 1],'UserData',[],'visible','off','callback',@surfstatFDR); 
   
hnd_SBMPWS.savedata=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
    'position',[1170 125 80 30],'string','Save Data','FontSize',12, ...
    'backgroundcolor',[1 1 1],'visible','on','callback',@savedata);   

%% other controls   
hnd_SBMPWS.mainmanu=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
    'position',[1170 80 80 30],'string','Main Manu','FontSize',12, ...
    'backgroundcolor',[1 1 1],'callback',@mainmanu);
function mainmanu(varargin)  
%   close(gcf)  
  clear global hnd_SBMPWSdata 
  NeuroimagingPheWAS
end

hnd_SBMPWS.quit=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','pushbutton',...
    'position',[1170 40 80 30],'string','Quit','FontSize',12, ...
    'backgroundcolor',[1 1 1],'callback',@quit);
function quit(varargin)  
  close(gcf)  
  clear global hnd_SBMPWSdata  
  fprintf('Thanks for using NeuroimagingPheWAS. Bye! \n');
end
  
%% logo
hnd_SBMPWS.BDDSlogo_part1=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
      'position',[15+670 30 90 60],'string','BD','FontSize',60,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.7 0 0],'HorizontalAlignment','left');   
hnd_SBMPWS.BDDSlogo_part2=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
      'position',[98+670 30 90 60],'string','DS','FontSize',60,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0 0 0.4],'HorizontalAlignment','left');
hnd_SBMPWS.BDDSlogo_part3=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
      'position',[110+750 33 70 25],'string','Big Data','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.7 0 0],'HorizontalAlignment','left');
hnd_SBMPWS.BDDSlogo_part4=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
      'position',[185+750 33 30 25],'string','for','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0.5 0.5 0.5],'HorizontalAlignment','left');
hnd_SBMPWS.BDDSlogo_part5=uicontrol(hnd_SBMPWS.mainfig,'units','pixels','style','text',...
      'position',[212+750 33 160 25],'string','Discovery Science','FontSize',18,...
      'backgroundcolor',[1 1 1],'ForegroundColor',[0 0 0.4],'HorizontalAlignment','left'); 

   
%% Callback functions for surface model visualization

function surffn=surfacemodel(varargin)  % obtain the directory and filename for selected surface model
  [file,path]=uigetfile('*.*','Open data file');  
  surffn=[path file];
  set(hnd_SBMPWS.surf_dir,'string',surffn,'FontSize',12);
  set(hnd_SBMPWS.surfacemodel , 'UserData' , surffn);
end

function surf_data=load_surface(varargin)  % load and visualize surface model
  statusbar(hnd_SBMPWS.mainfig, 'Loading surface model ...');
  surffn=get(hnd_SBMPWS.surfacemodel , 'UserData'); 
  [surf_model,ab]=SurfStatReadSurf(surffn);   
  surf_data = get(hnd_SBMPWS.load_surface,'UserData');
  a=surf_data.a; 
  if ~isempty(a)
      delete(surf_data.a); 
      surf_data=struct('surf_model',[],'a',[],'cb',[],'inflation',0,'mask',(ones(1,length(surf_model.coord))>0));
      set(hnd_SBMPWS.load_surface , 'UserData' , surf_data);
  end
  [a,cb] = SurfStatView_forGUI(ones(1,length(surf_model.coord)),surf_model,'Surface Model','white',0.05,hnd_SBMPWS.panel_surfviewer);
  surf_data=struct('surf_model',surf_model,'a',a,'cb',cb,'inflation',0,'mask',(ones(1,length(surf_model.coord))>0));
  set(hnd_SBMPWS.load_surface , 'UserData' , surf_data);
  databagstatus(1)=1; 
  statusbar;
end


function inflatecheck(varargin)  % check if inflation is required
         inflateflag = get(hnd_SBMPWS.inflateckeck,'value');
        if inflateflag==1
            set(hnd_SBMPWS.inflateR,'visible','on');
            set(hnd_SBMPWS.inflatetrigger,'visible','on');
        elseif inflateflag==0
            set(hnd_SBMPWS.inflateR,'visible','off');
            set(hnd_SBMPWS.inflatetrigger,'visible','off');
        end
end

function surf_data=apply_inflation(varargin)  % inflate the surface
     statusbar(hnd_SBMPWS.mainfig, 'Inflating surface model ...');
     inflation_param = str2num(get(hnd_SBMPWS.inflateR,'string'));
     surf_data = get(hnd_SBMPWS.load_surface,'UserData');
     surf_model = SurfStatInflate(surf_data.surf_model,inflation_param);
     if ~isempty(surf_data.a)
        delete(surf_data.a);
     end
     [a,cb] = SurfStatView_forGUI(ones(1,length(surf_model.coord)).*surf_data.mask,surf_model,'Surface Model','white',0.05,hnd_SBMPWS.panel_surfviewer);
     surf_data=struct('surf_model',surf_model,'a',a,'cb',cb,'inflation',1,'mask',surf_data.mask);
     set( hnd_SBMPWS.load_surface, 'UserData' , surf_data);
     statusbar;
end

function maskfn=surfacemask(varargin)  % obtain directory and filename of selected mask
  [file,path]=uigetfile('*.*','Open data file');  
  maskfn=[path file];
  set(hnd_SBMPWS.mask_dir,'string',maskfn,'FontSize',12);
  set(hnd_SBMPWS.surfacemask,'UserData',maskfn);
end

function surf_data=apply_mask(varargin)  % mask out the interhemispheric cut
     statusbar(hnd_SBMPWS.mainfig, 'Masking interhemispheric cut ...');
     inflateflag = get(hnd_SBMPWS.inflateckeck,'value');
     maskfn = get(hnd_SBMPWS.surfacemask,'UserData');
     maskdata=load(maskfn);
     mask=logical(maskdata.mask); 
     surf_data = get(hnd_SBMPWS.load_surface,'UserData'); 
     if ~isempty(surf_data.a)
        delete(surf_data.a);
     end
     [a,cb] = SurfStatView_forGUI(ones(1,length(surf_data.surf_model.coord)).*mask,surf_data.surf_model,'Surface Model','white',0.05,hnd_SBMPWS.panel_surfviewer);
     surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',mask);
     set( hnd_SBMPWS.load_surface, 'UserData' , surf_data );
     statusbar;
end

function clear_surfviewer(varargin)
         surf_data=get(hnd_SBMPWS.load_surface , 'UserData'); 
         surf_model=surf_data.surf_model;
         a=surf_data.a;
         if ~isempty(a)
            delete(surf_data.a); 
            surf_data=struct('surf_model',surf_model,'a',[],'cb',[],'inflation',0,'mask',ones(1,327684));
            set(hnd_SBMPWS.load_surface , 'UserData' , surf_data);
         end 
end

function save_image(varargin)
        [filename, pathname] = uiputfile({'*.jpg';'*.tif';'*.png';'*.eps';'*.bmp';'*.fig'},'Save Image');
        if isequal(filename,0)||isequal(pathname,0)
            return;
        else
            statusbar(hnd_SBMPWS.mainfig, 'Saving image ...');
            set(gcf, 'PaperPositionMode', 'manual');
            set(gcf, 'PaperUnits', 'points');
            set(gcf,'Paperposition',[20 30 660 580]);
            fpath=fullfile(pathname,filename);
            [pathstr, name, ext] = fileparts(fpath);
            set(hnd_SBMPWS.panel_surfviewer,'BorderType','none','Title','');
            set(hnd_SBMPWS.panel_surfacemodel,'BorderType','none');
            set(hnd_SBMPWS.clear_surfviewer,'visible','off');
            set(hnd_SBMPWS.save_image,'visible','off');
            switch ext
                case '.png'
                    print(gcf,fpath,'-dpng');
                case '.tif'
                    print(gcf,fpath,'-dtiff');
                case '.jpg'
                    print(gcf,fpath,'-djpeg');
                case '.bmp'
                    print(gcf,fpath,'-dbmp');
                case '.eps'
                    print(gcf,fpath,'-depsc');
            end
            set(hnd_SBMPWS.panel_surfviewer,'BorderType','etchedin','Title','Surface Viewer');
            set(hnd_SBMPWS.panel_surfacemodel,'BorderType','etchedin');
            set(hnd_SBMPWS.clear_surfviewer,'visible','on');
            set(hnd_SBMPWS.save_image,'visible','on');    
            statusbar;
            msgbox('Image has been saved','');   
        end
end

%% Callback functions for genotype data control

function genofn=genodata(varargin)  % obtain the directory and filename for selected geno data
  [file,path]=uigetfile('*.*','Open data file'); 
  genofn=[path file];
  set(hnd_SBMPWS.genodatapath,'string',[path file],'FontSize',12);
  set(hnd_SBMPWS.genodata,'UserData',genofn);
end
    
function geno_data=loadgenodata(varargin) % load selected geno data
   statusbar(hnd_SBMPWS.mainfig, 'Loading genotype data ...');
   genofn = get(hnd_SBMPWS.genodata,'UserData');
   geno_data = read_mixed_csv(genofn,',');  
   if nnz(ismember(geno_data(:,2),'1-Jan'))~=0
      geno_data(ismember(geno_data(:,2),'1-Jan'),2)={'1/1'}; % correct wrongly converted variant by excel
   end
   set(hnd_SBMPWS.loadgenodata,'UserData',geno_data);  
   set(hnd_SBMPWS.txt_genodata,'string','Genotype data has been loaded :)','ForegroundColor','g');
   
   snp_ID = cell2mat(geno_data(1,2));  
   set(hnd_SBMPWS.txt_snpID,'string',['SNP ID: ',snp_ID],'visible','on');  
   set(hnd_SBMPWS.snpdistribution,'visible','on'); 
   databagstatus(2)=1;
   
    set(hnd_SBMPWS.txt_databagstatus,'visible','off');
    set(hnd_SBMPWS.databagtidy,'visible','off');
    set(hnd_SBMPWS.txt_maineffect,'visible','off');
    set(hnd_SBMPWS.maineffect,'visible','off'); 
    set(hnd_SBMPWS.txt_test,'visible','off');
    set(hnd_SBMPWS.testlist,'visible','off');
    set(hnd_SBMPWS.txt_effectsign,'visible','off');   
    set(hnd_SBMPWS.effectsign,'visible','off');       
    set(hnd_SBMPWS.doanalysis,'visible','off'); 
    set(hnd_SBMPWS.uncorrectedpmap,'visible','off');  
    set(hnd_SBMPWS.txt_uncorrPthrhd,'visible','off');  
    set(hnd_SBMPWS.uncorrPthrhd,'visible','off');
    set(hnd_SBMPWS.applyucorrPthrhd,'visible','off');
    set(hnd_SBMPWS.txt_clusthrhd,'visible','off');
    set(hnd_SBMPWS.clusthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatRFT,'visible','off');
    set(hnd_SBMPWS.txt_FDRthrhd,'visible','off');
    set(hnd_SBMPWS.FDRthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatFDR,'visible','off');  
   
   statusbar;
end

function h=snpdistribution(varargin) % plot histogram for variants of the selected SNP 
         geno_data=get(hnd_SBMPWS.loadgenodata,'UserData');
         h=figure('Name','SNP distribution in sample','Numbertitle','off');hist(ordinal(geno_data(2:end,2))); 
         title(['SNP ',cell2mat(geno_data(1,2)),' variants distribution'],'FontSize',16,'FontWeight','Bold');
         xlabel('Variants','FontSize',16,'FontWeight','Bold');ylabel('Number of subjects','FontSize',16,'FontWeight','Bold');
         ah=findobj(h,'type','axes');
         set(ah,'fontsize',14);
         set(hnd_SBMPWS.snpdistribution,'UserData',h);
end

%% callback functions for model control

function covfn=covdata(varargin)  % obtain filename and directory of covariates data
  [file,path]=uigetfile('*.*','Open data file'); 
  covfn=[path file];
  set(hnd_SBMPWS.covdatapath,'string',[path file],'FontSize',12);
  set(hnd_SBMPWS.covdata, 'UserData' , covfn );
end

function cov_data=loadcovdata(varargin) % load covariates data
   statusbar(hnd_SBMPWS.mainfig, 'Loading covariates data ...');
   covfn = get(hnd_SBMPWS.covdata,'UserData');
   cov_data = read_mixed_csv(covfn,',');
   set(hnd_SBMPWS.loadcovdata,'UserData',cov_data);  
   set(hnd_SBMPWS.txt_covdata,'string','Covariates data has been loaded :)','ForegroundColor','g');
   set(hnd_SBMPWS.txt_cov,'visible','on');
   cov_list = 'genotype';
        for i=2:size(cov_data,2)
            cov_list=[cov_list,'|', cell2mat(cov_data(1,i))];
        end
   set(hnd_SBMPWS.covlist,'string',cov_list,'value',1,'visible','on');
   set(hnd_SBMPWS.covorder,'visible','on');
   set(hnd_SBMPWS.txt_interaction,'visible','on');
   set(hnd_SBMPWS.interactionckeck,'visible','on');
   set(hnd_SBMPWS.addcov,'visible','on');  
   statusbar;
end

function addcov(varargin)
       model=get(hnd_SBMPWS.model,'string');
       cov_data=get(hnd_SBMPWS.loadcovdata,'UserData');
       cov_list=cell(1,size(cov_data,2));
       cov_list(1)={'genotype'}; 
       cov_list(2:end)=cov_data(1,2:end);
       cov_selected_id = get(hnd_SBMPWS.covlist,'value');
       cov_order = get(hnd_SBMPWS.covorder,'value');
       interactionflag = get(hnd_SBMPWS.interactionckeck,'value');

       if cov_order==1
          cov_new = cell2mat(cov_list(cov_selected_id)); 
       else cov_new = [cell2mat(cov_list(cov_selected_id)),'^',num2str(cov_order)]; 
       end
       
       if interactionflag==0
          model = [model, ' + ', cov_new];
       else 
          cov_selected_id2 = get(hnd_SBMPWS.covlist2,'value');
          cov_order2 = get(hnd_SBMPWS.covorder2,'value');
          if cov_order2==1
             cov_new2 = cell2mat(cov_list(cov_selected_id2)); 
          else cov_new2 = [cell2mat(cov_list(cov_selected_id2)),'^',num2str(cov_order2)]; 
          end
          model = [model, ' + ', cov_new,'*',cov_new2];
       end
          set(hnd_SBMPWS.model,'string',model,'backgroundcolor',[1 1 1].*0.8);   
          set(hnd_SBMPWS.txt_modelstatus,'string','Model is NOT choosen :(','ForegroundColor','r');
          databagstatus(3)=0;
end

function interactionckeck(varargin) % check if an interaction is required
         flag = get(hnd_SBMPWS.interactionckeck,'value');
        if flag==1
           cov_data=get(hnd_SBMPWS.loadcovdata,'UserData');
           cov_list = 'genotype';
           for i=2:size(cov_data,2)
               cov_list=[cov_list,'|', cell2mat(cov_data(1,i))];
           end           
           set(hnd_SBMPWS.covlist2,'string',cov_list,'value',1,'visible','on');
           set(hnd_SBMPWS.covorder2,'visible','on');
        elseif flag==0
           set(hnd_SBMPWS.covlist2,'visible','off');
           set(hnd_SBMPWS.covorder2,'visible','off');
        end    
end

function model=choosemodel(varargin) % choose the model for PheWAS
         model=get(hnd_SBMPWS.model,'string');
         set(hnd_SBMPWS.model,'backgroundcolor','c');
         set(hnd_SBMPWS.txt_modelstatus,'string','Model is choosen :)','ForegroundColor','g');
         set(hnd_SBMPWS.choosemodel,'UserData',model);
         databagstatus(3)=1;
         
        set(hnd_SBMPWS.txt_databagstatus,'visible','off');
        set(hnd_SBMPWS.databagtidy,'visible','off');
        set(hnd_SBMPWS.txt_maineffect,'visible','off');
        set(hnd_SBMPWS.maineffect,'visible','off'); 
        set(hnd_SBMPWS.txt_test,'visible','off');
        set(hnd_SBMPWS.testlist,'visible','off');
        set(hnd_SBMPWS.txt_effectsign,'visible','off');   
        set(hnd_SBMPWS.effectsign,'visible','off');           
        set(hnd_SBMPWS.doanalysis,'visible','off'); 
        set(hnd_SBMPWS.uncorrectedpmap,'visible','off');  
        set(hnd_SBMPWS.txt_uncorrPthrhd,'visible','off');  
        set(hnd_SBMPWS.uncorrPthrhd,'visible','off');
        set(hnd_SBMPWS.applyucorrPthrhd,'visible','off');
        set(hnd_SBMPWS.txt_clusthrhd,'visible','off');
        set(hnd_SBMPWS.clusthrhd,'visible','off');
        set(hnd_SBMPWS.surfstatRFT,'visible','off');
        set(hnd_SBMPWS.txt_FDRthrhd,'visible','off');
        set(hnd_SBMPWS.FDRthrhd,'visible','off');
        set(hnd_SBMPWS.surfstatFDR,'visible','off'); 
         
end

function modelbgcolor(varargin)
    set(hnd_SBMPWS.model,'backgroundcolor',[1 1 1].*0.8);  
    set(hnd_SBMPWS.txt_modelstatus,'string','Model is NOT choosen :)','ForegroundColor','r');
    databagstatus(3)=0;
end


%% callback functions for phenotype data control

function phenodatadir=phenodataDIR(varargin)  % obtain the directory where phenotype data is saved
  phenodatadir=uigetdir('');
  set(hnd_SBMPWS.phenodatadir,'string',[phenodatadir,'/'],'FontSize',12);
  set(hnd_SBMPWS.phenodataDIR, 'UserData' , phenodatadir );
end

function phenoclasslistfn=phenoclasslist(varargin)  % obtain the directory where phenotype data is saved
  [file,path]=uigetfile('*.*','Open data file'); 
  phenoclasslistfn=[path file];
  set(hnd_SBMPWS.phenoclasslistdir,'string',[path file],'FontSize',12);
  set(hnd_SBMPWS.phenoclasslist, 'UserData' , phenoclasslistfn );
end

function phenoclass_list=loadphenoclasslist(varargin) % load the list of phenotype classes included in the PheWAS
   statusbar(hnd_SBMPWS.mainfig, 'Loading phenotype classes list ...');
   phenoclasslistfn = get(hnd_SBMPWS.phenoclasslist,'UserData');
   phenoclass_list = read_mixed_csv(phenoclasslistfn,',');  
   set(hnd_SBMPWS.loadphenoclasslist,'UserData',phenoclass_list);  
   set(hnd_SBMPWS.txt_phenoclass,'visible','on');
         
   phenotype_classes=['1: ',cell2mat(phenoclass_list(1))];
        for i=2:length(phenoclass_list)
            phenotype_classes=[phenotype_classes,'|', num2str(i),': ', cell2mat(phenoclass_list(i))];
        end      
   set(hnd_SBMPWS.phenotypeclass,'string',phenotype_classes,'value',1,'UserData',zeros(size(phenotype_classes)),'visible','on');   
   set(hnd_SBMPWS.loadphenodata,'visible','on'); 
   set(hnd_SBMPWS.txt_kernel,'visible','on');  
   set(hnd_SBMPWS.txt_kernel_unit,'visible','on');
   set(hnd_SBMPWS.kernel,'visible','on');
   statusbar;
end


function checkselectedphenotypedata(varargin) % check if the data of selected phenotype is loaded or not
         phenodata_check = get(hnd_SBMPWS.phenotypeclass,'UserData');
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
         if phenodata_check(pheno_selection)==0
             set(hnd_SBMPWS.txt_phenodata,'string',['Data of ',phenoclass_selected,' has NOT been loaded :('],'ForegroundColor','r');            
         elseif phenodata_check(pheno_selection)==1
             set(hnd_SBMPWS.txt_phenodata,'string',['Data of ',phenoclass_selected,' has been loaded :)'],'ForegroundColor','g'); 
         end      
         databagstatus(4)=phenodata_check(pheno_selection);
end


function phenodata=loadphenodata(varargin) % load phenotype data
    statusbar(hnd_SBMPWS.mainfig, 'Loading phenotype data ...');
    phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
    pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
    phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
    phenodatadir = get(hnd_SBMPWS.phenodataDIR, 'UserData');
    list=dir(phenodatadir);
    subj_pheno={list.name}';
    subj_pheno=subj_pheno(3:end);
    s=1;
    phenodata=cell(1,3);
    phenodata(1,1)={'subjID'};
    phenodata(1,2)={'lh_phenotypes'};
    phenodata(1,3)={'rh_phenotypes'};
    
    kernel=get(hnd_SBMPWS.kernel,'string');
    kernel=strrep(kernel,' ','');
    for j = 1 : length(subj_pheno)
        files=dir([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/*h.',phenoclass_selected,'.*.',kernel,'mm.mgh']);
        fn={files.name};
        if length(fn)>1
            fn_parts=strsplit(cell2mat(fn(1)),'.');
            if (exist([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/lh.',phenoclass_selected,'.',cell2mat(fn_parts(3)),'.',kernel,'mm.mgh'])~=0)&&...
                    (exist([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/rh.',phenoclass_selected,'.',cell2mat(fn_parts(3)),'.',kernel,'mm.mgh'])~=0)
                s=s+1;
                phenodata(s,1)=subj_pheno(j);
                tk1 = MRIread([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/lh.',phenoclass_selected,'.',cell2mat(fn_parts(3)),'.',kernel,'mm.mgh']);
                phenodata(s,2)={tk1.vol};
                tk2 = MRIread([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/rh.',phenoclass_selected,'.',cell2mat(fn_parts(3)),'.',kernel,'mm.mgh']);
                phenodata(s,3)={tk2.vol};            
            end
        end
    end    
    
%     for j = 1 : length(subj_pheno)
%         if (exist([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/lh.',phenoclass_selected,'.fsaverage.',kernel,'mm.mgh'])~=0)&&...
%                 (exist([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/rh.',phenoclass_selected,'.fsaverage.',kernel,'mm.mgh'])~=0)
%             s=s+1;
%             phenodata(s,1)=subj_pheno(j);
%             tk1 = MRIread([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/lh.',phenoclass_selected,'.fsaverage.',kernel,'mm.mgh']);
%             phenodata(s,2)={tk1.vol};
%             tk2 = MRIread([phenodatadir,'/',cell2mat(subj_pheno(j)),'/surf/rh.',phenoclass_selected,'.fsaverage.',kernel,'mm.mgh']);
%             phenodata(s,3)={tk2.vol};            
%         end
%     end
    
    if s==1 % if no phenotype data is found
         h=msgbox('Phenotype data is not found. Please check input of ''Phenotype Data DIR'', ''Phenotype Class'' or ''Smoothing Kernel''', 'Error','error');
         set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
         uiwait(h);       
         return;
    end
    
    set(hnd_SBMPWS.loadphenodata, 'UserData' , phenodata );
    phenodata_check=zeros(size(phenoclass_list));
    phenodata_check(pheno_selection)=1;
    set(hnd_SBMPWS.phenotypeclass,'UserData',phenodata_check);
    set(hnd_SBMPWS.txt_phenodata,'string',['Data of ',phenoclass_selected,' has been loaded :)'],'ForegroundColor','g');    
    set(hnd_SBMPWS.viewphenomean,'visible','on');
    databagstatus(4)=1;
    
    set(hnd_SBMPWS.txt_databagstatus,'visible','off');
    set(hnd_SBMPWS.databagtidy,'visible','off');
    set(hnd_SBMPWS.txt_maineffect,'visible','off');
    set(hnd_SBMPWS.maineffect,'visible','off'); 
    set(hnd_SBMPWS.txt_test,'visible','off');
    set(hnd_SBMPWS.testlist,'visible','off');
    set(hnd_SBMPWS.txt_effectsign,'visible','off');   
    set(hnd_SBMPWS.effectsign,'visible','off');      
    set(hnd_SBMPWS.doanalysis,'visible','off'); 
    set(hnd_SBMPWS.uncorrectedpmap,'visible','off');  
    set(hnd_SBMPWS.txt_uncorrPthrhd,'visible','off');  
    set(hnd_SBMPWS.uncorrPthrhd,'visible','off');
    set(hnd_SBMPWS.applyucorrPthrhd,'visible','off');
    set(hnd_SBMPWS.txt_clusthrhd,'visible','off');
    set(hnd_SBMPWS.clusthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatRFT,'visible','off');
    set(hnd_SBMPWS.txt_FDRthrhd,'visible','off');
    set(hnd_SBMPWS.FDRthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatFDR,'visible','off');     
    
    statusbar;
end

function viewphenomean(varargin)  % visualize the mean values of the selected phenotype class
     statusbar(hnd_SBMPWS.mainfig, 'Visualizing mean values of the selected phenotype class ...');
     phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
     pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
     phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
     phenodata = get(hnd_SBMPWS.loadphenodata, 'UserData');
     Y=[cell2mat(phenodata(2:end,2)) cell2mat(phenodata(2:end,3))];
     Ymean = mean(Y);
     surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
     if ~isempty(surf_data.a)
        delete(surf_data.a);
     end
     if nnz(ismember(phenoclass_selected,'_'))>0
         phenoclass_selected=strrep(phenoclass_selected,'_','\_');
     end
     [a,cb] = SurfStatView_forGUI(Ymean.*surf_data.mask,surf_data.surf_model,['Mean ',phenoclass_selected,' across subjects'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
     surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
     set( hnd_SBMPWS.load_surface, 'UserData',surf_data);
     hdt = datacursormode;
     set(hdt,'DisplayStyle','datatip');
     statusbar;
end

%% callback functions for PheWAS control
function validatedatabag(varargin) % validate if the databag is ready for PheWAS
         statusbar(hnd_SBMPWS.mainfig, 'Validating databag ...');
         invalidfileds=find(databagstatus==0);
         if isempty(invalidfileds)
            set(hnd_SBMPWS.txt_databagstatus,'string','All required data has been loaded :)','ForegroundColor','g','visible','on');
            set(hnd_SBMPWS.databagtidy,'visible','on');              
            
%             pheno_data=get(hnd_SBMPWS.loadphenodata,'UserData');
%             geno_data=get(hnd_SBMPWS.loadgenodata,'UserData'); 
%             variants=geno_data(2:end,2);
%             M=get(hnd_SBMPWS.choosemodel,'UserData');
%             factors=unique(strsplit(M,{'\s*\+\s*','\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
%             factors(ismember(factors,'1'))=[];
%             if length(factors)==nnz(ismember(factors,'genotype'))
%                 if (length(variants)==size(pheno_data,1))&&(nnz(ismember(variants,{'','N/A','n/a','NA','na'}))==0)
%                     set(hnd_SBMPWS.txt_databagstatus,'string','Databag is ready for PheWAS :)','ForegroundColor','g','visible','on');
%                     set(hnd_SBMPWS.txt_maineffect,'visible','on');
%                     effects_cell=strsplit(M,'\s*\+\s*','DelimiterType','RegularExpression');  
%                     effects_str=cell2mat(effects_cell(1));
%                     for i=2:length(effects_cell)
%                         effects_str=[effects_str,'|', cell2mat(effects_cell(i))];
%                     end
%                     set(hnd_SBMPWS.maineffect,'visible','on','string',effects_str,'UserData',effects_cell); 
%                     set(hnd_SBMPWS.txt_test,'visible','on');
%                     set(hnd_SBMPWS.testlist,'visible','on');
%                     set(hnd_SBMPWS.doanalysis,'visible','on');                         
%                 elseif (length(variants)~=size(pheno_data,1))
%                     set(hnd_SBMPWS.txt_databagstatus,'string','Databag is loaded, but needs Tidying','ForegroundColor','r','visible','on');
%                     set(hnd_SBMPWS.databagtidy,'visible','on');
%                 elseif (length(variants)==size(pheno_data,1))&&(nnz(ismember(variants,{'','N/A','n/a','NA','na'}))>0)
%                     set(hnd_SBMPWS.txt_databagstatus,'string','Databag is loaded, but needs Tidying','ForegroundColor','r','visible','on');
%                     set(hnd_SBMPWS.databagtidy,'visible','on');                                                        
%                 end
%             elseif length(factors)>nnz(ismember(factors,'genotype'))
%                 confondingfactors=factors;confondingfactors(ismember(confondingfactors,'genotype'))=[];
%                 cov_data=get(hnd_SBMPWS.loadcovdata,'UserData');
%                 cov_data_selected=cov_data(:,ismember(cov_data(1,:),confondingfactors));
%                 if (length(variants)==size(pheno_data,1))&&(length(cov_data_selected)==size(pheno_data,1))...
%                         &&(nnz(ismember(variants,{'','N/A','n/a','NA','na'}))==0)&&(nnz(ismember(cov_data_selected,{'','N/A','n/a','NA','na'}))==0)
%                     set(hnd_SBMPWS.txt_databagstatus,'string','Databag is ready for PheWAS :)','ForegroundColor','g');
%                 elseif (length(variants)~=size(pheno_data,1))||(length(cov_data_selected)~=size(pheno_data,1))||(length(variants)~=length(cov_data_selected))
%                     set(hnd_SBMPWS.txt_databagstatus,'string','Databag is loaded, but needs Tidying','ForegroundColor','r','visible','on');
%                     set(hnd_SBMPWS.databagtidy,'visible','on');
%                 elseif (length(variants)==size(pheno_data,1))&&(length(cov_data_selected)==size(pheno_data,1))...
%                         &&((nnz(ismember(variants,{'','N/A','n/a','NA','na'}))>0)||(nnz(ismember(cov_data_selected,{'','N/A','n/a','NA','na'}))>0))
%                     set(hnd_SBMPWS.txt_databagstatus,'string','Databag is loaded, but needs Tidying','ForegroundColor','r','visible','on');
%                     set(hnd_SBMPWS.databagtidy,'visible','on');                                                       
%                 end                  
%             end
   
         elseif length(invalidfileds)==1 
                set(hnd_SBMPWS.txt_databagstatus,'string', [cell2mat(databagfields(invalidfileds)),' is NOT ready for PheWAS :('],'ForegroundColor','r','visible','on'); 
         elseif length(invalidfileds)>1
                invalidfieldsnames=cell2mat(databagfields(invalidfileds(1)));
                for i=2:length(invalidfileds)
                    invalidfieldsnames=[invalidfieldsnames, ', ',cell2mat(databagfields(invalidfileds(i)))];
                end
                set(hnd_SBMPWS.txt_databagstatus,'string', [invalidfieldsnames,' is NOT ready :('],'ForegroundColor','r','visible','on'); 
         end  
         statusbar;
end


function tidieddatabag=databagtidy(varargin) % tidy databag to control missing data   
         statusbar(hnd_SBMPWS.mainfig, 'Tidying databag ...');
         pheno_data=get(hnd_SBMPWS.loadphenodata,'UserData');
         pheno_meas=[cell2mat(pheno_data(2:end,2)) cell2mat(pheno_data(2:end,3))];
         subjID_pheno = pheno_data(2:end,1);  
         clear pheno_data;
         geno_data=get(hnd_SBMPWS.loadgenodata,'UserData');
         subjID_geno = geno_data(2:end,1); 
         variants=geno_data(2:end,2);
         M=get(hnd_SBMPWS.choosemodel,'UserData'); 
         factors=unique(strsplit(M,{'\s*\+\s*','\s*\*\s*','\s*\^2\s*','\s*\^3\s*',' '},'DelimiterType','RegularExpression'));
         factors(ismember(factors,'1'))=[];factors(ismember(factors,''))=[]; 
         [Li_pheno,Loc_geno] = ismember(subjID_pheno,subjID_geno);
         tidieddatabag.leftside = pheno_meas(Li_pheno,:);
         tidieddatabag.rightside(1:nnz(Li_pheno),1)=subjID_pheno(Li_pheno);
         tidieddatabag.rightside(1:nnz(Li_pheno),2)=variants(nonzeros(Loc_geno)); 
                
         if length(factors)>nnz(ismember(factors,'genotype'))  
            confoundingfactors=factors(logical(1-ismember(factors,'genotype')));
            cov_data=get(hnd_SBMPWS.loadcovdata,'UserData');
            cov_data_selected=cov_data(2:end,ismember(cov_data(1,:),confoundingfactors)); 
            factors=[{'genotype'},cov_data(1,ismember(cov_data(1,:),confoundingfactors))];  
            subjID_cov = cov_data(2:end,1);
            [Li_valid1,Loc_cov] = ismember(tidieddatabag.rightside(:,1),subjID_cov);
            tidieddatabag.leftside = tidieddatabag.leftside(Li_valid1,:);
            tidieddatabag.rightside = tidieddatabag.rightside(Li_valid1,:);         
            tidieddatabag.rightside(1:nnz(Li_valid1),3:3+length(confoundingfactors)-1)=cov_data_selected(Loc_cov,:);            
         end
         miss_data_check=zeros(length(tidieddatabag.rightside),1);
         for k = 1 : length(tidieddatabag.rightside)
             miss_data_check(k)=sum(ismember(tidieddatabag.rightside(k,:),{'./.','','N/A','n/a','NA','na'}));   
         end
         if nnz(miss_data_check)~=0
             tidieddatabag.leftside((miss_data_check>0),:)=[];
             tidieddatabag.rightside((miss_data_check>0),:)=[];
         end
         tidieddatabag.rightside(2:length(tidieddatabag.rightside)+1,:) = tidieddatabag.rightside;
         tidieddatabag.rightside(1,:)=[{'subjID'},factors];
         set(hnd_SBMPWS.databagtidy,'UserData',tidieddatabag);
         set(hnd_SBMPWS.txt_databagstatus,'string','Databag is ready for PheWAS :)','ForegroundColor','g');

         set(hnd_SBMPWS.txt_maineffect,'visible','on');
         effects_cell=strsplit(M,'\s*\+\s*','DelimiterType','RegularExpression'); effects_cell(ismember(effects_cell,''))=[]; 
         effects_str=cell2mat(effects_cell(1));
         for i=2:length(effects_cell)
             effects_str=[effects_str,'|', cell2mat(effects_cell(i))];
         end
         set(hnd_SBMPWS.maineffect,'visible','on','string',effects_str,'UserData',effects_cell,'value',1);     
         set(hnd_SBMPWS.txt_test,'visible','on');
         set(hnd_SBMPWS.testlist,'visible','on'); 
         set(hnd_SBMPWS.doanalysis,'visible','on');        
         
         statusbar;
end

 function action_maineffect(varargin)
    set(hnd_SBMPWS.txt_effectsign,'visible','off');   
    set(hnd_SBMPWS.effectsign,'visible','off');      
    set(hnd_SBMPWS.uncorrectedpmap,'visible','off');  
    set(hnd_SBMPWS.txt_uncorrPthrhd,'visible','off');  
    set(hnd_SBMPWS.uncorrPthrhd,'visible','off');
    set(hnd_SBMPWS.applyucorrPthrhd,'visible','off');
    set(hnd_SBMPWS.txt_clusthrhd,'visible','off');
    set(hnd_SBMPWS.clusthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatRFT,'visible','off');
    set(hnd_SBMPWS.txt_FDRthrhd,'visible','off');
    set(hnd_SBMPWS.FDRthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatFDR,'visible','off');       
 end


 function action_testlist(varargin)
    set(hnd_SBMPWS.txt_effectsign,'visible','off');   
    set(hnd_SBMPWS.effectsign,'visible','off');      
    set(hnd_SBMPWS.uncorrectedpmap,'visible','off');  
    set(hnd_SBMPWS.txt_uncorrPthrhd,'visible','off');  
    set(hnd_SBMPWS.uncorrPthrhd,'visible','off');
    set(hnd_SBMPWS.applyucorrPthrhd,'visible','off');
    set(hnd_SBMPWS.txt_clusthrhd,'visible','off');
    set(hnd_SBMPWS.clusthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatRFT,'visible','off');
    set(hnd_SBMPWS.txt_FDRthrhd,'visible','off');
    set(hnd_SBMPWS.FDRthrhd,'visible','off');
    set(hnd_SBMPWS.surfstatFDR,'visible','off');       
 end

function slm=doanalysis(varargin) % run the selected test
         test_selection=get(hnd_SBMPWS.testlist,'value');
         test_list=get(hnd_SBMPWS.testlist,'UserData');
         test_selected=cell2mat(test_list(test_selection));
         
         
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));
         
         if (strcmp(maineffect,'1')==1)&&(ismember({test_selected},{'ANOVA','t-test','F-test'}))
             h=msgbox('Main effect is the constant. Please choose Linear Regression.', 'Error','error');
             set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
             uiwait(h);
             return;
  
         elseif strcmp(maineffect,'1')~=1
         
                 tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
                 factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3',' '},'DelimiterType','RegularExpression'));         
                 factors_maineffect(ismember(factors_maineffect,''))=[];
                 factor_check=0;
                 for j=1:length(factors_maineffect)
                     tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
                     factor_check=factor_check + all(ismember(cell2mat(tmp(1)),'0123456789+-.eEdD')); 
                 end   

                 num_category=0;
                 for j=1:length(factors_maineffect)
                     tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
                     if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==1
                         num_category(j)=0;
                     else num_category(j)=length(unique(tmp));
                     end
                 end
                
                 
                 if (factor_check<length(factors_maineffect))&&(ismember({test_selected},{'Linear Regression'}))
                     h=msgbox('Main effect contains categorical variables. Please choose ANOVA, t-test or F-test.', 'Error','error');
                     set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
                     uiwait(h);       
                     return;
                 elseif (factor_check==length(factors_maineffect))&&(ismember({test_selected},'t-test'))
                     h=msgbox('Main effect contains continous variables. Please choose Linear Regression or F-test.', 'Error','error');
                     set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
                     uiwait(h);                          
                     return;
                 elseif (factor_check<length(factors_maineffect))&&(ismember({test_selected},{'t-test'}))&&(max(num_category)>2)
                     h=msgbox('Main effect contains more than 2 categorical variants. Please choose ANOVA or F-test.', 'Error','error');
                     set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
                     uiwait(h);                             
                     return 
                 end
         
         end
         
         test_selected1=test_selected;
         if nnz(ismember(test_selected1,'-'))
            test_selected1=strrep(test_selected1,'-','');
         elseif nnz(ismember(test_selected1,' '))
             test_selected1=strrep(test_selected1,' ','');
         end

         slm=eval(['do',lower(test_selected1)]);
         set(hnd_SBMPWS.doanalysis,'UserData',slm); 
 
         if nnz(ismember(test_selected,{'t-test','Linear Regression'}))>0 
            set(hnd_SBMPWS.txt_effectsign,'visible','on');   
            set(hnd_SBMPWS.effectsign,'visible','on');  
         else
            set(hnd_SBMPWS.txt_effectsign,'visible','off');   
            set(hnd_SBMPWS.effectsign,'visible','off'); 
         end
         
         set(hnd_SBMPWS.uncorrectedpmap,'visible','on');  
         set(hnd_SBMPWS.txt_clusthrhd,'visible','on');
         set(hnd_SBMPWS.clusthrhd,'visible','on');
         set(hnd_SBMPWS.surfstatRFT,'visible','on');
         set(hnd_SBMPWS.txt_FDRthrhd,'visible','on');
         set(hnd_SBMPWS.FDRthrhd,'visible','on');
         set(hnd_SBMPWS.surfstatFDR,'visible','on');      
         
         
end

function slm=doanova(varargin) % do ANOVA for selected main effect and visualize the F-map
         statusbar(hnd_SBMPWS.mainfig, 'Doing ANOVA ...');
         M=get(hnd_SBMPWS.choosemodel,'UserData');
         factors=unique(strsplit(M,{'\s*\+\s*','\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
         factors(ismember(factors,'1'))=[];factors(ismember(factors,''))=[];
         tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
         nm_factors=length(factors);
         factors_data=[];
         Term=[]; 
         for j = 1 : nm_factors
              M=strrep(M,cell2mat(factors(j)),['Term.',cell2mat(factors(j))]); % replace factors with terms in the model 
              
              % load factors' data
              tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors(j)))); 
              if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==0
                 factors_data.(cell2mat(factors(j)))=tmp;
              else v=0;
                  for i=1:length(tmp)
                      v(i,1)=str2num(cell2mat(tmp(i)));
                  end
                 factors_data.(cell2mat(factors(j)))=v;    
              end
              
              Term.(cell2mat(factors(j)))=term(factors_data.(cell2mat(factors(j))));
         end
                          
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));
  
         effects_cell1=effects_cell;
         effects_cell1(ismember(effects_cell1,maineffect))=[];
         M1=cell2mat(effects_cell1(1));
         if length(effects_cell1)>1
            for j=2:length(effects_cell1)
                M1=[M1,' + ',cell2mat(effects_cell1(j))];
            end
         end
         factors1=unique(strsplit(M1,{'\s*\+\s*','\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
         factors1(ismember(factors1,'1'))=[];factors1(ismember(factors1,''))=[];
         for j=1:length(factors1)
             M1=strrep(M1,cell2mat(factors1(j)),['Term.',cell2mat(factors1(j))]); % replace factors with terms in the model 
         end        
         
         Model0=eval([M,';']); 
         Model1=eval([M1,';']);
         
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         
         slm0=SurfStatLinMod(tidieddatabag.leftside,Model0,surf_data.surf_model);         
         slm1=SurfStatLinMod(tidieddatabag.leftside,Model1,surf_data.surf_model);
         slm = SurfStatF( slm0, slm1 );
         
         if nnz(isinf(slm.t))>0
             h=msgbox('ANOVA failed. Please check the model or change to a proper test.', 'Error','error');
             set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
             uiwait(h);                          
             return;             
         end
         
         
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end
         [a,cb] = SurfStatView_forGUI(slm.t.*surf_data.mask,surf_data.surf_model,['Effects of ',maineffect,' on ',phenoclass_selected,...
             ' (F map, df=[',num2str(slm.df(1)),', ',num2str(slm.df(2)),'])'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');        
         statusbar;
end

function slm=dolinearregression(varargin) % do linear regression for selected main effect and visualize the T-map
         statusbar(hnd_SBMPWS.mainfig, 'Doing linear regression ...');
         M=get(hnd_SBMPWS.choosemodel,'UserData');
         factors=unique(strsplit(M,{'\s*\+\s*','\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
         factors(ismember(factors,'1'))=[];factors(ismember(factors,''))=[];
         tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
         nm_factors=length(factors);
         factors_data=[];
         Term=[]; 
         for j = 1 : nm_factors
              M=strrep(M,cell2mat(factors(j)),['Term.',cell2mat(factors(j))]); % replace factors with terms in the model 
              
              % load factors' data
              tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors(j)))); 
              if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==0
                 factors_data.(cell2mat(factors(j)))=tmp;
              else v=0;
                  for i=1:length(tmp)
                      v(i,1)=str2num(cell2mat(tmp(i)));
                  end
                 factors_data.(cell2mat(factors(j)))=v;    
              end
              
              Term.(cell2mat(factors(j)))=term(factors_data.(cell2mat(factors(j))));
         end
                          
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));               
         
         Model=eval([M,';']);
         
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         
         slm=SurfStatLinMod(tidieddatabag.leftside,Model,surf_data.surf_model); 
         
         if strcmp(maineffect,'1')==1
             contrast=slm.X(:,1);
         else
             factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3', ' '},'DelimiterType','RegularExpression'));
             factors_maineffect(ismember(factors_maineffect,''))=[];
             maineffect_contrast=maineffect;
             for j = 1 : length(factors_maineffect)
                    maineffect_contrast = strrep(maineffect_contrast,cell2mat(factors_maineffect(j)),['factors_data.',cell2mat(factors_maineffect(j))]);
             end
             maineffect_contrast=strrep(maineffect_contrast,'*','.*');maineffect_contrast=strrep(maineffect_contrast,'^','.^');
             contrast=eval(maineffect_contrast);
         end
         
         slm = SurfStatT( slm, contrast);
              
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end
         [a,cb] = SurfStatView_forGUI(slm.t.*surf_data.mask,surf_data.surf_model,['Effects of ',maineffect,' on ',phenoclass_selected,...
             ' (T map, df=',num2str(slm.df),')'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');        
         statusbar;
end

function slm=dottest(varargin) % do t-test for selected main effect and visualize the T-map
         statusbar(hnd_SBMPWS.mainfig, 'Doing t-test ...');
         M=get(hnd_SBMPWS.choosemodel,'UserData');
         factors=unique(strsplit(M,{'\s*\+\s*','\*','\^2','^3', ' '},'DelimiterType','RegularExpression'));
         factors(ismember(factors,'1'))=[];factors(ismember(factors,''))=[];
         tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
         nm_factors=length(factors);
         factors_data=[];
         Term=[]; 
         for j = 1 : nm_factors
              M=strrep(M,cell2mat(factors(j)),['Term.',cell2mat(factors(j))]); % replace factors with terms in the model 
              
              % load factors' data
              tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors(j)))); 
              if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==0
                 factors_data.(cell2mat(factors(j)))=tmp;
              else v=0;
                  for i=1:length(tmp)
                      v(i,1)=str2num(cell2mat(tmp(i)));
                  end
                 factors_data.(cell2mat(factors(j)))=v;    
              end
              
              Term.(cell2mat(factors(j)))=term(factors_data.(cell2mat(factors(j))));
         end
                          
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));               
         
         Model=eval([M,';']);
         
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         
         slm=SurfStatLinMod(tidieddatabag.leftside,Model,surf_data.surf_model); 
         
         factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
         factors_maineffect(ismember(factors_maineffect,''))=[];
         num_category=0; categories=cell(1,1);
         for j=1:length(factors_maineffect)
             tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
             if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==1
                 num_category(j)=0;
                 categories(j)={''};
             else
                 num_category(j)=length(unique(tmp));
                 categories(j)={unique(tmp)};
             end
         end
         
         maineffect_contrast=maineffect; 
         contrast_text = maineffect;
         for j = 1 : length(factors_maineffect)
             if num_category(j)==2
                 maineffect_contrast = strrep(maineffect_contrast,cell2mat(factors_maineffect(j)),...
                     ['(Term.',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(1)),'-Term.',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(2)),')']);
                     contrast_text=strrep(contrast_text,cell2mat(factors_maineffect(j)),...
                     ['(',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(1)),' - ',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(2)),')']);
             else maineffect_contrast = strrep(maineffect_contrast,cell2mat(factors_maineffect(j)),['factors_data.',cell2mat(factors_maineffect(j))]);
             end
         end
         maineffect_contrast=strrep(maineffect_contrast,'*','.*');
         maineffect_contrast=strrep(maineffect_contrast,'^','.^');

         contrast=eval(maineffect_contrast);

         slm = SurfStatT( slm, contrast);
              
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end
         [a,cb] = SurfStatView_forGUI(slm.t.*surf_data.mask,surf_data.surf_model,['Effects of ',contrast_text,' on ',phenoclass_selected,...
             ' (T map, df=',num2str(slm.df),')'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');        
         statusbar;
end


function slm=doftest(varargin) % do F-test for selected main effect and visualize the F-map
         statusbar(hnd_SBMPWS.mainfig, 'Doing F-test ...');
         M=get(hnd_SBMPWS.choosemodel,'UserData');
         factors=unique(strsplit(M,{'\s*\+\s*','\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
         factors(ismember(factors,'1'))=[];factors(ismember(factors,''))=[];
         tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
         nm_factors=length(factors);
         factors_data=[];
         Term=[]; 
         for j = 1 : nm_factors
              M=strrep(M,cell2mat(factors(j)),['Term.',cell2mat(factors(j))]); % replace factors with terms in the model 
              
              % load factors' data
              tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors(j)))); 
              if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==0
                 factors_data.(cell2mat(factors(j)))=tmp;
              else v=0;
                  for i=1:length(tmp)
                      v(i,1)=str2num(cell2mat(tmp(i)));
                  end
                 factors_data.(cell2mat(factors(j)))=v;    
              end
              
              Term.(cell2mat(factors(j)))=term(factors_data.(cell2mat(factors(j))));
         end
         
         
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));
         
         effects_cell1=effects_cell;
         effects_cell1(ismember(effects_cell1,maineffect))=[];
         M1=cell2mat(effects_cell1(1));
         if length(effects_cell1)>1
            for j=2:length(effects_cell1)
                M1=[M1,' + ',cell2mat(effects_cell1(j))];
            end
         end
         factors1=unique(strsplit(M1,{'\s*\+\s*','\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
         factors1(ismember(factors1,'1'))=[];factors1(ismember(factors1,''))=[];
         for j=1:length(factors1)
             M1=strrep(M1,cell2mat(factors1(j)),['Term.',cell2mat(factors1(j))]); % replace factors with terms in the model 
         end
         
         Model0=eval([M,';']);  
         Model1=eval(M1,';'); 
         
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         
         slm0=SurfStatLinMod(tidieddatabag.leftside,Model0,surf_data.surf_model);         
         slm1=SurfStatLinMod(tidieddatabag.leftside,Model1,surf_data.surf_model);
         slm = SurfStatF( slm0, slm1 );
  
         if nnz(isinf(slm.t))>0            
             h=msgbox('F-test failed. Please check the model or a change to proper test.', 'Error','error');
             set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
             uiwait(h);              
             return;
         end        
         
          
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end
         [a,cb] = SurfStatView_forGUI(slm.t.*surf_data.mask,surf_data.surf_model,['Effects of ',maineffect,' on ',phenoclass_selected,...
             ' (F map, df=[',num2str(slm.df(1)),', ',num2str(slm.df(2)),'])'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');        
         statusbar;
end



function uncorrP=uncorrectedpmap(varargin)
         statusbar(hnd_SBMPWS.mainfig, 'Visualizing map of -log(uncorrected P) ...');
         slm = get(hnd_SBMPWS.doanalysis,'UserData');

         test_selection=get(hnd_SBMPWS.testlist,'value');
         test_list=get(hnd_SBMPWS.testlist,'UserData');
         test_selected=cell2mat(test_list(test_selection));         
         if nnz(ismember(test_selected,{'t-test','Linear Regression'}))>0
             effectsigins = get(hnd_SBMPWS.effectsign,'UserData');
             effectsiginselection = get(hnd_SBMPWS.effectsign,'value');
             signselected=cell2mat(effectsigins(effectsiginselection));
             if strcmp(signselected,'+')==1
                 sign=1;
                 direction='Positive effects';
             elseif strcmp(signselected,'-')==1
                 sign=-1;
                 direction='Negative effects';
             end
         else
             sign=1;
             direction='Effects';
         end         
    
         if length(slm.df)==1
            uncorrP = tcdf(slm.t.*sign,slm.df,'upper');
         elseif length(slm.df)==2
            uncorrP = fcdf(slm.t,slm.df(1),slm.df(2),'upper');        
         end
         set(hnd_SBMPWS.uncorrectedpmap,'UserData',uncorrP);
         
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));        
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
          
         if nnz(isinf(-log10(uncorrP)))>0
             h=msgbox('There are extremely small P values that exceed allowed precision.', 'Error','error');
             set(h, 'position', [Pos(1)+1/2*Pos(3) Pos(2)+1/2*Pos(4) 500 70]);htxt = findobj(h,'Type','text');set(htxt,'FontSize',12);
             uiwait(h);
             return;
         end 
         
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end
         
         if strcmp(test_selected,'t-test')==1   
             tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
             factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
             factors_maineffect(ismember(factors_maineffect,''))=[];
             num_category=0; categories=cell(1,1);
             for j=1:length(factors_maineffect)
                 tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
                 if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==1
                     num_category(j)=0;
                     categories(j)={''};
                 else
                     num_category(j)=length(unique(tmp));
                     categories(j)={unique(tmp)};
                 end
             end
             contrast_text = maineffect;
             for j = 1 : length(factors_maineffect)
                 if num_category(j)==2
                         contrast_text=strrep(contrast_text,cell2mat(factors_maineffect(j)),...
                         ['(',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(1)),' - ',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(2)),')']);
                 end
             end
             maineffect=contrast_text;
         end
         
         
         [a,cb] = SurfStatView_forGUI(-log10(uncorrP).*surf_data.mask,surf_data.surf_model,[direction,' of ',maineffect,' on ',phenoclass_selected,...
             ' (-log(uncorrected P) map, df=[',num2str(slm.df),'])'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);     
         
         set(hnd_SBMPWS.txt_uncorrPthrhd,'visible','on');  
         set(hnd_SBMPWS.uncorrPthrhd,'visible','on');
         set(hnd_SBMPWS.applyucorrPthrhd,'visible','on');
                 
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');
         statusbar;
end


function applyucorrPthrhd(varargin)   
         statusbar(hnd_SBMPWS.mainfig, 'Thresholding map of -log(uncorrected P) ...');
         slm = get(hnd_SBMPWS.doanalysis,'UserData');
         uncorrP = get(hnd_SBMPWS.uncorrectedpmap,'UserData');
         thrhd = str2num(get(hnd_SBMPWS.uncorrPthrhd,'string'));

         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));        
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
         
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end

         test_selection=get(hnd_SBMPWS.testlist,'value');
         test_list=get(hnd_SBMPWS.testlist,'UserData');
         test_selected=cell2mat(test_list(test_selection));        
         if nnz(ismember(test_selected,{'t-test','Linear Regression'}))>0
             effectsigins = get(hnd_SBMPWS.effectsign,'UserData');
             effectsiginselection = get(hnd_SBMPWS.effectsign,'value');
             signselected=cell2mat(effectsigins(effectsiginselection));
             if strcmp(signselected,'+')==1
                 sign=1;
                 direction='Positive effects';
             elseif strcmp(signselected,'-')==1
                 sign=-1;
                 direction='Negative effects';
             end
         else
             direction='Effects';
         end         

         if strcmp(test_selected,'t-test')==1   
             tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
             factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
             factors_maineffect(ismember(factors_maineffect,''))=[];
             num_category=0; categories=cell(1,1);
             for j=1:length(factors_maineffect)
                 tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
                 if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==1
                     num_category(j)=0;
                     categories(j)={''};
                 else
                     num_category(j)=length(unique(tmp));
                     categories(j)={unique(tmp)};
                 end
             end
             contrast_text = maineffect;
             for j = 1 : length(factors_maineffect)
                 if num_category(j)==2
                         contrast_text=strrep(contrast_text,cell2mat(factors_maineffect(j)),...
                         ['(',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(1)),' - ',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(2)),')']);
                 end
             end
             maineffect=contrast_text;
         end         
         
         [a,cb] = SurfStatView_forGUI(-log10(uncorrP).*(uncorrP<thrhd).*surf_data.mask,surf_data.surf_model,[direction,' of ',maineffect,' on ',phenoclass_selected,...
             ' (-log(uncorrected P<',num2str(thrhd),') map, df=[',num2str(slm.df),'])'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);        
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');
         statusbar; 
end

function RFT_stats=surfstatRFT(varargin)  
         statusbar(hnd_SBMPWS.mainfig, 'Applying Random Field Theory correction ...');
         slm = get(hnd_SBMPWS.doanalysis,'UserData');
         
         test_selection=get(hnd_SBMPWS.testlist,'value');
         test_list=get(hnd_SBMPWS.testlist,'UserData');
         test_selected=cell2mat(test_list(test_selection));         
         if nnz(ismember(test_selected,{'t-test','Linear Regression'}))>0
             effectsigins = get(hnd_SBMPWS.effectsign,'UserData');
             effectsiginselection = get(hnd_SBMPWS.effectsign,'value');
             signselected=cell2mat(effectsigins(effectsiginselection));
             if strcmp(signselected,'+')==1
                 sign=1;
                 direction='Positive effects';
             elseif strcmp(signselected,'-')==1
                 sign=-1;
                 direction='Negative effects';
             end
         else
             sign=1;
             direction='Effects';
         end  
         
         slm.t=slm.t.*sign;
         RFT_stats.clusthrhd = str2num(get(hnd_SBMPWS.clusthrhd,'string'));
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         [ RFT_stats.pval, RFT_stats.peak, RFT_stats.clus ] = SurfStatP(slm,surf_data.mask,RFT_stats.clusthrhd);
         
         set(hnd_SBMPWS.surfstatRFT,'UserData',RFT_stats);
         
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));        
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
                 
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end

         if strcmp(test_selected,'t-test')==1  
             tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
             factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
             factors_maineffect(ismember(factors_maineffect,''))=[];
             num_category=0; categories=cell(1,1);
             for j=1:length(factors_maineffect)
                 tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
                 if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==1
                     num_category(j)=0;
                     categories(j)={''};
                 else
                     num_category(j)=length(unique(tmp));
                     categories(j)={unique(tmp)};
                 end
             end
             contrast_text = maineffect;
             for j = 1 : length(factors_maineffect)
                 if num_category(j)==2
                         contrast_text=strrep(contrast_text,cell2mat(factors_maineffect(j)),...
                         ['(',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(1)),' - ',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(2)),')']);
                 end
             end
             maineffect=contrast_text;
         end         
         
         [a,cb] = SurfStatView_forGUI(RFT_stats.pval,surf_data.surf_model,[direction,' of ',maineffect,' on ',phenoclass_selected,...
             ' (RFT corrected P map, df=[',num2str(slm.df),'])'],'white',0.05,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);        
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');
         statusbar;        
end

function FDR_stats=surfstatFDR(varargin)
         statusbar(hnd_SBMPWS.mainfig, 'Applying False Discovery Rate correction ...');
         slm = get(hnd_SBMPWS.doanalysis,'UserData');

         test_selection=get(hnd_SBMPWS.testlist,'value');
         test_list=get(hnd_SBMPWS.testlist,'UserData');
         test_selected=cell2mat(test_list(test_selection));         
         if nnz(ismember(test_selected,{'t-test','Linear Regression'}))>0
             effectsigins = get(hnd_SBMPWS.effectsign,'UserData');
             effectsiginselection = get(hnd_SBMPWS.effectsign,'value');
             signselected=cell2mat(effectsigins(effectsiginselection));
             if strcmp(signselected,'+')==1
                 sign=1;
                 direction='Positive effects';
             elseif strcmp(signselected,'-')==1
                 sign=-1;
                 direction='Negative effects';
             end
         else
             sign=1;
             direction='Effects';
         end  
         
         slm.t=slm.t.*sign;         
         
         FDR_stats.clusthrhd = str2num(get(hnd_SBMPWS.FDRthrhd,'string'));
         surf_data = get( hnd_SBMPWS.load_surface, 'UserData');
         FDR_stats.qval = SurfStatQ(slm,surf_data.mask);
         
         set(hnd_SBMPWS.surfstatFDR,'UserData',FDR_stats);
         
         effect_selection=get(hnd_SBMPWS.maineffect,'value');
         effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
         maineffect=cell2mat(effects_cell(effect_selection));        
         phenoclass_list=get(hnd_SBMPWS.loadphenoclasslist,'UserData');
         pheno_selection = get(hnd_SBMPWS.phenotypeclass,'Value');
         phenoclass_selected = cell2mat(phenoclass_list(pheno_selection));
                 
         if ~isempty(surf_data.a)
            delete(surf_data.a);
         end
         if nnz(ismember(phenoclass_selected,'_'))>0
             phenoclass_selected=strrep(phenoclass_selected,'_','\_');
         end

         if strcmp(test_selected,'t-test')==1 
             tidieddatabag = get(hnd_SBMPWS.databagtidy,'UserData');
             factors_maineffect=unique(strsplit(maineffect,{'\*','\^2','^3',' '},'DelimiterType','RegularExpression'));
             factors_maineffect(ismember(factors_maineffect,''))=[];
             num_category=0; categories=cell(1,1);
             for j=1:length(factors_maineffect)
                 tmp=tidieddatabag.rightside(2:end,ismember(tidieddatabag.rightside(1,:),cell2mat(factors_maineffect(j)))); 
                 if all(ismember(cell2mat(tmp(1)), '0123456789+-.eEdD'))==1
                     num_category(j)=0;
                     categories(j)={''};
                 else
                     num_category(j)=length(unique(tmp));
                     categories(j)={unique(tmp)};
                 end
             end
             contrast_text = maineffect;
             for j = 1 : length(factors_maineffect)
                 if num_category(j)==2
                         contrast_text=strrep(contrast_text,cell2mat(factors_maineffect(j)),...
                         ['(',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(1)),' - ',cell2mat(factors_maineffect(j)),'.',cell2mat(categories{j}(2)),')']);
                 end
             end
             maineffect=contrast_text;
         end         
         
         [a,cb] = SurfStatView_forGUI(FDR_stats.qval,surf_data.surf_model,[direction,' effects of ',maineffect,' on ',phenoclass_selected,...
             ' (FDR corrected P map, df=[',num2str(slm.df),'])'],'white',FDR_stats.clusthrhd,hnd_SBMPWS.panel_surfviewer);
         surf_data = struct('surf_model',surf_data.surf_model,'a',a,'cb',cb,'inflation',surf_data.inflation,'mask',surf_data.mask); 
         set( hnd_SBMPWS.load_surface, 'UserData',surf_data);        
         hdt = datacursormode;
         set(hdt,'DisplayStyle','datatip');
         statusbar;     
end

function savedata(varargin)
            variables=cell(1,1);
            s=0;
            model=get(hnd_SBMPWS.choosemodel,'UserData');
            if ~isempty(model)
                s=s+1;
                variables(s)={'model'};
            end
%             databag=get(hnd_SBMPWS.databagtidy,'UserData');
%             if ~isempty(databag)
%                 s=s+1;
%                 variables(s)={'databag'};
%             end

            effect_selection=get(hnd_SBMPWS.maineffect,'value');
            effects_cell=get(hnd_SBMPWS.maineffect,'UserData');
            main_effect=cell2mat(effects_cell(effect_selection));           
            if ~isempty(main_effect)
                s=s+1; 
                variables(s)={'main_effect'};
            end
            
            test_selection=get(hnd_SBMPWS.testlist,'value');
            test_list=get(hnd_SBMPWS.testlist,'UserData');
            test=cell2mat(test_list(test_selection));
            if ~isempty(test)
                s=s+1; 
                variables(s)={'test'};
            end            
            
            slm=get(hnd_SBMPWS.doanalysis,'UserData');
            if ~isempty(slm)
                s=s+1;
                variables(s)={'slm'};
            end            
            P_uncorrected=get(hnd_SBMPWS.uncorrectedpmap,'UserData');
            if ~isempty(P_uncorrected)
                s=s+1;
                variables(s)={'P_uncorrected'};
            end    
            RFT_stats=get(hnd_SBMPWS.surfstatRFT,'UserData');
            if ~isempty(RFT_stats)
                s=s+1;
                variables(s)={'RFT_stats'};
            end
            FDR_stats=get(hnd_SBMPWS.surfstatFDR,'UserData');
            if ~isempty(FDR_stats)
                s=s+1;
                variables(s)={'FDR_stats'};
            end
            uisave(variables,'PheWAS_data');
            msgbox('PheWAS data has been saved','');
end


end