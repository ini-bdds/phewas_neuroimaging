function [ a, cb ] = SurfStatViewData_forGUI( data, surf, title, background, thrhd,parent_handle,type)
% SurfStatViewData_forGUI.m create a basic viewer for surface data.
% SurfStatViewData_forGUI.m is developed based on the SurfStatViewData.m function
% included in the SurfStat package (http://www.math.mcgill.ca/keith/surfstat/).

% Usage: [ a, cb ] = SurfStatViewData( data, surf,title,background );
% 
% data        = 1 x v vector of data, v=#vertices
% surf.coord  = 3 x v matrix of coordinates.
% surf.tri    = t x 3 matrix of triangle indices, 1-based, t=#triangles.
% title       = any string, data name by default.
% background  = background colour, any matlab ColorSpec, such as 
%   'white' (default), 'black'=='k', 'r'==[1 0 0], [1 0.4 0.6] (pink) etc.
%   Letter and line colours are inverted if background is dark (mean<0.5).
% thrhd         = cluster threshold.
% parent_handle = the handle of parent uipanel
% type        = the type of surface data ('regular': regular data; 
%                                         'RFT': Random Field Theory statistics;
%                                         'FDR': False Discovery Rate satistics).
%
% a  = vector of handles to the axes, left to right, top to bottom. 
% cb = handle to the colorbar.

if nargin<3 
    title=inputname(1);
end
if nargin<4
    background='white';
end


% find cut between hemispheres, assuming they are concatenated
t=size(surf.tri,1);
v=size(surf.coord,2);
tmax=max(surf.tri,[],2);
tmin=min(surf.tri,[],2);
% to save time, check that the cut is half way
if min(tmin(t/2+1:t))-max(tmax(1:t/2))==1
    cut=t/2;
    cuv=v/2;
else % check all cuts
    for i=1:t-1
        tmax(i+1)=max(tmax(i+1),tmax(i));
        tmin(t-i)=min(tmin(t-i),tmin(t-i+1));
    end
    cut=min([find((tmin(2:t)-tmax(1:t-1))==1) t]);
    cuv=tmax(cut);
end
tl=1:cut;
tr=(cut+1):t;
vl=1:cuv;
vr=(cuv+1):v;

clim=[min(data),max(data)];
if clim(1)==clim(2)
    clim=clim(1)+[-1 0];
end


colormap(spectral(256));

w=176;
h=148;
w1=120;
h1=110;

a(1)=axes('units','pixels','position',[20 370 w h],'parent',parent_handle);
trisurf(surf.tri(tl,:),surf.coord(1,vl),surf.coord(2,vl),surf.coord(3,vl),...
    double(data(vl)),'EdgeColor','none');
view(-90,0); 
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;

a(2)=axes('units','pixels','position',[240 360 h w],'parent',parent_handle);
trisurf(surf.tri,surf.coord(1,:),surf.coord(2,:),surf.coord(3,:),...
    double(data),'EdgeColor','none');
view(0,90); 
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;

a(3)=axes('units','pixels','position',[430 370 w h],'parent',parent_handle);
trisurf(surf.tri(tr,:)-cuv,surf.coord(1,vr),surf.coord(2,vr),surf.coord(3,vr),...
        double(data(vr)),'EdgeColor','none');
    view(90,0);
    daspect([1 1 1]); axis tight; camlight; axis vis3d off;
    lighting phong; material shiny; shading interp;


a(4)=axes('units','pixels','position',[20 210  w h],'parent',parent_handle);
trisurf(surf.tri(tl,:),surf.coord(1,vl),surf.coord(2,vl),surf.coord(3,vl),...
    double(data(vl)),'EdgeColor','none');
view(90,0); 
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;

a(5)=axes('units','pixels','position',[240 190 h w],'parent',parent_handle);
trisurf(surf.tri,surf.coord(1,:),surf.coord(2,:),surf.coord(3,:),...
    double(data),'EdgeColor','none');
view(0,-90); 
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;

a(6)=axes('units','pixels','position',[430 210 w h],'parent',parent_handle);
trisurf(surf.tri(tr,:)-cuv,surf.coord(1,vr),surf.coord(2,vr),surf.coord(3,vr),...
    double(data(vr)),'EdgeColor','none');
view(-90,0);
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;

a(7)=axes('units','pixels','position',[30 90 w1 h1],'parent',parent_handle);
trisurf(surf.tri,surf.coord(1,:),surf.coord(2,:),surf.coord(3,:),...
    double(data),'EdgeColor','none');
view(180,0);
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;

a(8)=axes('units','pixels','position',[480 90 w1 h1],'parent',parent_handle);
trisurf(surf.tri,surf.coord(1,:),surf.coord(2,:),surf.coord(3,:),...
    double(data),'EdgeColor','none');
view(0,0);
daspect([1 1 1]); axis tight; camlight; axis vis3d off;
lighting phong; material shiny; shading interp;
   
    
id0=[0 0 cuv 0 0 cuv 0 0];
for i=1:length(a)
    set(a(i),'CLim',clim);
    set(a(i),'Tag',['SurfStatView ' num2str(i) ' ' num2str(id0(i))]);
end

if strcmp(type,'regular')==1
    cb=colorbar('location','South');
    set(cb,'units','pixels','Position',[155 40 300 20]);
    set(cb,'XAxisLocation','bottom');
    h=get(cb,'Title');
    set(h,'String',title,'FontSize',14);
elseif strcmp(type,'RFT')==1
        cm=[zeros(1,3);
            zeros(127,1)   (0:126)'/127   ones(127,1); ones(1,3)*0.8;
            ones(127,1)    (0:126)'/127   zeros(127,1)];
        colormap(cm); 
        cb=colorbar('location','South');
        set(cb,'units','pixels','Position',[155 40 300 20]);
        set(cb,'XAxisLocation','bottom');
        h=get(cb,'Title');
        set(h,'String',title,'FontSize',14);
        clim=[0 255]*thrhd ;
        set(a,'CLim',clim);
        
        set(cb,'XLim',[0 255]*thrhd);
        hcb=get(cb,'Children');
        set(hcb,'XData',[0 255]*thrhd);
        set(cb,'XTick',[1 64 127 129 192 255]*thrhd);
        pstr1=num2str(round(thrhd*1000)/1000);
        pstr2=num2str(round(thrhd*1000/2)/1000);
        set(cb,'XTickLabel',strvcat(['     ' pstr1],['   ' pstr2],...
            ' ',['   0 ' pstr1],['   ' pstr2],'   0'));
        xl=get(cb,'XLabel');
        set(xl,'String','P Cluster               P Vertex','FontSize',14);
elseif strcmp(type,'FDR')==1
        cm=[zeros(1,3); ones(1,3)*0.8; ones(254,1) (0:253)'/254 zeros(254,1)];
        colormap(cm); 
        cb=colorbar('location','South');
        set(cb,'units','pixels','Position',[155 40 300 20]);
        set(cb,'XAxisLocation','bottom');
        h=get(cb,'Title');
        set(h,'String',title,'FontSize',14);
        clim=[0 255]*thrhd ;
        set(a,'CLim',clim);

        set(cb,'XLim',[0 255]*thrhd);
        hcb=get(cb,'Children');
        set(hcb,'XData',[0 255]*thrhd);
        set(cb,'XTick',(2+(0:5)/5*253)*thrhd);
        set(cb,'XTickLabel',num2str(thrhd*(5:-1:0)'/5));
        xl=get(cb,'XLabel');
        set(xl,'String','Q','FontSize',14);
    
end

whitebg(gcf,background);
set(gcf,'Color',background,'InvertHardcopy','off');

dcm_obj=datacursormode(gcf);
set(dcm_obj,'UpdateFcn',@SurfStatDataCursor,'DisplayStyle','window');


return
end

