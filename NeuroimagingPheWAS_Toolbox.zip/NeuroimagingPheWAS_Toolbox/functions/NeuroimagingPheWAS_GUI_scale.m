function varargout=NeuroimagingPheWAS_GUI_scale(varargin)
% NeuroimagingPheWAS, a toolbox for whole-brain PheWAS analysis, multiple
% comparisons correction and result visualization. 
%-----------------------------------------------------------
%	Copyright(c) 2016
%	University of Southern California
%	Written by Lu Zhao
%	Mail to Author:  <a href="lu.zhao@loni.usc.edu">Lu Zhao</a>
%   Version 1.0;
%   Date 08.15.2016;
%   Last edited 08.15.2016
%-----------------------------------------------------------
%
% NeuroimagingPheWAS_GUI_scale.m determines the window size and scale for
% the user interface.


Action = varargin{1};

switch lower(Action)
%=======================================================================
case 'winscale'                  %-Window scale factors (to fit display)
%=======================================================================
% WS = Neuroimaging_PheWAS_GUI_scale('WinScale')
%-----------------------------------------------------------------------
S0 = NeuroimagingPheWAS_GUI_scale('WinSize','0',1);

if all(ismember(S0(:),[0 1]))
   varargout = {[1 1 1 1]};
   return;
end

B = 50; % taskbar size
if ispc && isequal(S0,[1 1 1366 768])
   B = 80;
elseif ismac
   B = 110; % average size bottom Dock
end
tmp = [S0(3)/1152 (S0(4)-B)/900];

varargout = {min(tmp)*[1 1 1 1]};


%=======================================================================
case {'fontsize','fontsizes','fontscale'}                 %-Font scaling
%=======================================================================
% [FS,sf] = Neuroimaging_PheWAS_GUI_scale('FontSize',FS)
% [FS,sf] = Neuroimaging_PheWAS_GUI_scale('FontSizes',FS)
% sf = Neuroimaging_PheWAS_GUI_scale('FontScale')
%-----------------------------------------------------------------------
if nargin<2, FS=1:36; else FS=varargin{2}; end

offset     = 1;
%try, if ismac, offset = 1.4; end; end

sf  = offset + 0.85*(min(NeuroimagingPheWAS_GUI_scale('WinScale'))-1);

if strcmpi(Action,'fontscale')
   varargout = {sf};
else
   varargout = {ceil(FS*sf),sf};
end


%=======================================================================
case 'winsize'                 %-Standard GUI window locations and sizes
%=======================================================================
% Rect = Neuroimaging_PheWAS_GUI_scale('WinSize',Win,raw)
%-----------------------------------------------------------------------
if nargin<3, raw=0; else raw=1; end
if nargin<2, Win=''; else Win=varargin{2}; end

Rect = [[300 500 512 200];...
       [100 100 1280 760]];

if isempty(Win)
   %-All windows
elseif upper(Win(1))=='W'
   %-Welcome window
   Rect = Rect(1,:);
elseif upper(Win(1))=='S'
   %-SBM window
   Rect = Rect(2,:);
elseif Win(1)=='0'
   units = get(0,'Units');
   set(0,'Units','pixels');
   Rect = get(0, 'ScreenSize');
   set(0,'Units',units);
end

if ~raw
   WS = repmat(NeuroimagingPheWAS_GUI_scale('WinScale'),size(Rect,1),1);
   Rect = Rect.*WS; 
end

varargout = {Rect};

end
end